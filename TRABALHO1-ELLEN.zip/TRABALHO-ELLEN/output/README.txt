
//Ellen Cristhyna Ribeiro Macedo
//2018200008

// Ellen Cristhyna Ribeiro Macedo
#include <stdio.h>
#include <stdlib.h>
#include <math.h>  //equacoes
#include <time.h>  //clock

#define N_SISTEMAS 100  //numero maximo de sistemas
#define N_INTERACOES 100 //numero maximo de iteraçoes

void LerMatriz(FILE *arquivo, float matriz[][N_SISTEMAS+1], int dimensao);
void LerVetor(FILE *arquivo, float vetor[], int dimensao);
void Triangularizacao(float matriz[][N_SISTEMAS+1], int dimensao);
void SubstituicaoSucessiva(float matriz[][N_SISTEMAS+1], float solucao[], int dimensao);
void FatoracaoLU(float matriz[][N_SISTEMAS+1], int dimensao);
void GaussJacobi(float matriz[][N_SISTEMAS+1], float solucao[], float precisao, int dimensao);
void GaussSeidel(float matriz[][N_SISTEMAS+1], float solucao[], float precisao, int dimensao);
int Convergiu(float solucao[], float solucao_antiga[], int dimensao, float precisao);
void ImprimirMatriz(float matriz[][N_SISTEMAS+1], int dimensao);
void ImprimirVetor(float vetor[], int dimensao);

// le e preenche os elementos da matriz
void LerMatriz(FILE *arquivo, float matriz[][N_SISTEMAS+1], int dimensao) {
    for (int i = 0; i < dimensao; i++) {
        for (int j = 0; j < dimensao + 1; j++) {
            fscanf(arquivo, "%f", &matriz[i][j]);
        }
    }
}

// le e preenche os elementos do vetor
void LerVetor(FILE *arquivo, float vetor[], int dimensao) {
    for (int i = 0; i < dimensao; i++) {
        fscanf(arquivo, "%f", &vetor[i]);
    }
}

int main() {
    FILE *arquivo = fopen("C:\\Users\\Micro\\Documents\\VSCodeC\\TRABALHO-ELLEN\\output\\teste1.txt", "r");
    
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        return 1;
    }

    int dimensao;
    float precisao;
    float matriz[N_SISTEMAS][N_SISTEMAS+1];
    float solucao[N_SISTEMAS];

    while (fscanf(arquivo, "%d", &dimensao) != EOF) {
        fscanf(arquivo, "%f", &precisao);

        LerMatriz(arquivo, matriz, dimensao);
        LerVetor(arquivo, solucao, dimensao);

        clock_t inicio, fim;
        double tempo_gauss, tempo_jacobi, tempo_seidel;

        printf("Resolvendo o sistema linear:\n");

        ImprimirMatriz(matriz, dimensao);
        ImprimirVetor(solucao, dimensao);

        inicio = clock();
        Triangularizacao(matriz, dimensao);
        SubstituicaoSucessiva(matriz, solucao, dimensao);
        fim = clock();

        tempo_gauss = ((double)(fim - inicio)) / CLOCKS_PER_SEC;

        printf("\nSolucao pelo metodo da eliminacao de Gauss:\n");
        ImprimirVetor(solucao, dimensao);
        printf("Tempo de execucao: %.10f segundos\n", tempo_gauss);

        printf("\nResolvendo o sistema linear novamente:\n");

        inicio = clock();
        FatoracaoLU(matriz, dimensao);
        SubstituicaoSucessiva(matriz, solucao, dimensao);
        fim = clock();

        tempo_gauss = ((double)(fim - inicio)) / CLOCKS_PER_SEC;

        printf("\nSolucao pelo metodo da fatoracao LU:\n");
        ImprimirVetor(solucao, dimensao);
        printf("Tempo de execucao: %.10f segundos\n", tempo_gauss);

        printf("\nResolvendo o sistema linear pelo metodo iterativo de Jacobi:\n");

        inicio = clock();
        GaussJacobi(matriz, solucao, precisao, dimensao);
        fim = clock();

        tempo_jacobi = ((double)(fim - inicio)) / CLOCKS_PER_SEC;

        printf("\nSolucao pelo metodo de Jacobi:\n");
        ImprimirVetor(solucao, dimensao);
        printf("Tempo de execucao: %.10f segundos\n", tempo_jacobi);

        printf("\nResolvendo o sistema linear pelo metodo iterativo de Gauss-Seidel:\n");

        inicio = clock();
        GaussSeidel(matriz, solucao, precisao, dimensao);
        fim = clock();

        tempo_seidel = ((double)(fim - inicio)) / CLOCKS_PER_SEC;

        printf("\nSolucao pelo metodo de Gauss-Seidel:\n");
        ImprimirVetor(solucao, dimensao);
        printf("Tempo de execucao: %.10f segundos\n", tempo_seidel);

        printf("\n---------------------------------------\n");
    }

    fclose(arquivo);

    return 0;
}

void Triangularizacao(float matriz[][N_SISTEMAS+1], int dimensao) {
    for (int i = 0; i < dimensao - 1; i++) {
        for (int k = i + 1; k < dimensao; k++) {
            float fator = matriz[k][i] / matriz[i][i];
            for (int j = i; j < dimensao + 1; j++) {
                matriz[k][j] -= fator * matriz[i][j];
            }
        }
    }
}

void SubstituicaoSucessiva(float matriz[][N_SISTEMAS+1], float solucao[], int dimensao) {
    solucao[dimensao-1] = matriz[dimensao-1][dimensao] / matriz[dimensao-1][dimensao-1];
    for (int i = dimensao - 2; i >= 0; i--) {
        float soma = 0;
        for (int j = i + 1; j < dimensao; j++) {
            soma += matriz[i][j] * solucao[j];
        }
        solucao[i] = (matriz[i][dimensao] - soma) / matriz[i][i];
    }
}

void FatoracaoLU(float matriz[][N_SISTEMAS+1], int dimensao) {
    for (int i = 0; i < dimensao - 1; i++) {
        for (int k = i + 1; k < dimensao; k++) {
            float fator = matriz[k][i] / matriz[i][i];
            matriz[k][i] = fator;
            for (int j = i + 1; j < dimensao; j++) {
                matriz[k][j] -= fator * matriz[i][j];
            }
        }
    }
}

void GaussJacobi(float matriz[][N_SISTEMAS+1], float solucao[], float precisao, int dimensao) {
    float solucao_antiga[N_SISTEMAS];
    int iteracoes = 0;

    do {
        for (int i = 0; i < dimensao; i++) {
            solucao_antiga[i] = solucao[i];
        }

        for (int i = 0; i < dimensao; i++) {
            float soma = 0;
            for (int j = 0; j < dimensao; j++) {
                if (j != i) {
                    soma += matriz[i][j] * solucao_antiga[j];
                }
            }
            solucao[i] = (matriz[i][dimensao] - soma) / matriz[i][i];
        }

        iteracoes++;
    } while (!Convergiu(solucao, solucao_antiga, dimensao, precisao) && iteracoes < N_INTERACOES);

    printf("Numero de iteracoes de Jacobi: %d\n", iteracoes);
}

void GaussSeidel(float matriz[][N_SISTEMAS+1], float solucao[], float precisao, int dimensao) {
    float solucao_antiga[N_SISTEMAS];
    int iteracoes = 0;

    do {
        for (int i = 0; i < dimensao; i++) {
            solucao_antiga[i] = solucao[i];
        }

        for (int i = 0; i < dimensao; i++) {
            float soma1 = 0;
            for (int j = 0; j < i; j++) {
                soma1 += matriz[i][j] * solucao[j];
            }

            float soma2 = 0;
            for (int j = i + 1; j < dimensao; j++) {
                soma2 += matriz[i][j] * solucao_antiga[j];
            }

            solucao[i] = (matriz[i][dimensao] - soma1 - soma2) / matriz[i][i];
        }

        iteracoes++;
    } while (!Convergiu(solucao, solucao_antiga, dimensao, precisao) && iteracoes < N_INTERACOES);

    printf("Numero de iteracoes de Gauss-Seidel: %d\n", iteracoes);
}

int Convergiu(float solucao[], float solucao_antiga[], int dimensao, float precisao) {
    for (int i = 0; i < dimensao; i++) {
        if (fabs(solucao[i] - solucao_antiga[i]) > precisao) {
            return 0;
        }
    }
    return 1;
}

void ImprimirMatriz(float matriz[][N_SISTEMAS+1], int dimensao) {
    for (int i = 0; i < dimensao; i++) {
        for (int j = 0; j < dimensao + 1; j++) {
            printf("%.2f ", matriz[i][j]);
        }
        printf("\n");
    }
}

void ImprimirVetor(float vetor[], int dimensao) {
    for (int i = 0; i < dimensao; i++) {
        printf("%.10f ", vetor[i]);
    }
    printf("\n");
}


///////////////////////////////////////////////////////////////////////

A notação do arquivo txt é essa, exemplo:
***********************

3    			- dimensao 
0.0001			-precisao

 1.0 2.0 -1.0 6.0  	-Linha 0 da matriz: 1.0x + 2.0y - 1.0z = 6.0
 2.0 1.0 -2.0 5.0 	-Linha 1 da matriz: 2.0x + 1.0y - 2.0z = 5.0
-3.0 1.0  1.0 -1.0  	-Linha 2 da matriz:-3.0x + 1.0y + 1.0z = -1.0
3 
3
-6
Vetor [3 3 -6]
OBS: EXCLUIR AS LETRAS, MANTER SÓ NUMEROS.
***********************

 

/////////////LOGICA:VISTO EM SALA DE AULA/////////////////////////////

Metodos: Eliminação de Gauss
 Triangularizaçao
 Substituiçao Sucessiva

Metodos: Fatoração LU
 Fatoração
 2x Substituição Sucessiva


Metodos: Eliminação de Gauss-Jacobi e Seidel
Ax=b
Teste de parada (Convergiu), precisao ambos usam.
precisao como criterio de parada tambem

/////////////////////////////////////////////////////////////////////
BIBLIOTECAS USADAS 
stdio.h
stdlib.h
math.h soma, soma2....
time.h (calcular o tempo de execução)

//////////////////////////////////////////////////////////////////////
dimensao -numero de equaçoes a ser resolvido
N_SISTEMAS  - tamanho maximo do sistema a ser resolvido
N_ITERACOES - maximo de iteraçoes em jacobi e seidel

//////////////////////////////////////////////////////////////////////

Dificuldades:
 1 Arquivo com N sistemas nele, precisou de muitas alterações.